# 431GroupProject
Final project for CMPT 431

Main files for server
Host.java		In Game Folder
HostMenu.java	In Menus Folder
GameBoard.java	In Game Folder
Message.java	In Controller folder
ConnectionEndpoint.java	In Controller Folder
GameState.java	In Controller Folder

Main files for client
Client.java	In Game Folder
ClientMenu.java	In Menus Folder
GameBoard.java	In Game Folder
Message.java	In Controller Folder
ConnectionEndpoint.java	In Controller Folder
GameState.java	In Game Folder
